Cometen IRL Alerts - originale alertlyder konvertert til WAV

Kopier alle WAV-filene i sounds-mappen til:
~/CometenIRLAlerts/receiver/sounds/

Foreslått mapping finnes i SOUND_MAP.json.

Filene er konvertert fra de opplastede MP3-filene til:
- PCM 16-bit WAV
- 44.1 kHz
- stereo

Dette fungerer med:
pw-play {file}
