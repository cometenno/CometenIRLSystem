#!/usr/bin/env python3

from __future__ import annotations

import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any

import admin_control
import receiver
from status_leds import StatusLedController

LOG = logging.getLogger("cometen-irl-alerts")
VIDEO_STATUS_PATH = Path("/run/cometen-irl-video-status.json")
BME280_STATUS_PATH = Path("/run/cometen/bme280.json")
PWM_DEVICE_MATCH = "febf0030.pwm"


class ProbedStatusLedController(StatusLedController):
    def _read_root_video_payload(self) -> dict[str, Any] | None:
        try:
            payload = json.loads(VIDEO_STATUS_PATH.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                return None

            updated = float(payload.get("updated_unix", 0.0))
            stale_seconds = max(
                1.0,
                float(self.settings.get("video_probe_stale_seconds", 3.0)),
            )
            if updated <= 0 or (time.time() - updated) > stale_seconds:
                return None
            return payload
        except Exception:
            return None

    def _read_root_video_probe(self) -> tuple[bool, bool, list[int]] | None:
        payload = self._read_root_video_payload()
        if payload is None:
            return None

        active = bool(payload.get("active", False))
        encoder_running = bool(payload.get("encoder_running", False))
        raw_pid = payload.get("pid")
        pids: list[int] = []
        if raw_pid is not None:
            try:
                pids.append(int(raw_pid))
            except (TypeError, ValueError):
                pass
        return active, encoder_running, pids

    def _video_state(self) -> tuple[bool | None, bool, list[int]]:
        probed = self._read_root_video_probe()
        if probed is not None:
            return probed
        return super()._video_state()

    def _live_process_active(self) -> bool:
        probed = self._read_root_video_probe()
        if probed is not None:
            return probed[1]
        return super()._live_process_active()

    def _log_video_transition(
        self,
        camera: bool | None,
        live_process: bool,
        process_tree: list[int],
    ) -> None:
        if camera == self._last_video_state:
            return
        self._last_video_state = camera

        payload = self._read_root_video_payload()
        if payload is not None:
            source_present = bool(payload.get("source_present", camera is True))
            pipeline_active = bool(payload.get("pipeline_active", False))

            if source_present and live_process and pipeline_active:
                LOG.info("Video input active: source present and BELABOX encoder pipeline is using it")
            elif source_present and not live_process:
                LOG.info("Video input available: source present, BELABOX encoder is stopped")
            elif live_process:
                LOG.warning("Video input missing: BELABOX encoder is running but video pipeline is not active")
            else:
                LOG.info("Video input unavailable: no local video source detected")
            return

        super()._log_video_transition(camera, live_process, process_tree)


def read_temperature() -> str:
    try:
        raw = float(Path("/sys/class/thermal/thermal_zone0/temp").read_text(encoding="utf-8").strip())
        if raw > 1000:
            raw /= 1000.0
        return f"CPU{int(round(raw))}C"
    except Exception:
        return "CPU?"


def read_case_temperature() -> str:
    try:
        if time.time() - BME280_STATUS_PATH.stat().st_mtime > 20:
            return "Case?"
        payload = json.loads(BME280_STATUS_PATH.read_text(encoding="utf-8"))
        value = float(payload["temperature_c"])
        return f"Case{int(round(value))}C"
    except Exception:
        return "Case?"


def read_fan_state() -> str:
    try:
        for chip in Path("/sys/class/pwm").glob("pwmchip*"):
            try:
                device = os.path.realpath(chip / "device")
            except Exception:
                continue
            if PWM_DEVICE_MATCH not in device:
                continue

            pwm = chip / "pwm0"
            period = int((pwm / "period").read_text(encoding="utf-8").strip())
            duty = int((pwm / "duty_cycle").read_text(encoding="utf-8").strip())
            if period <= 0:
                return "Fan?"
            percent = int(round(duty * 100.0 / period))
            return f"Fan{percent}%"
    except Exception:
        pass
    return "Fan?"


def build_expanded_status(config: dict[str, Any]) -> str:
    match_text = str(config.get("remote_audio_sink_match", "WPS200")).strip() or "WPS200"

    try:
        sink = receiver.resolve_audio_sink(config)
        audio = f"{match_text} OK n{sink}"
    except Exception:
        audio = f"{match_text} OFF"

    wifi = receiver.current_wifi_status()
    if wifi.startswith("WiFi "):
        wifi = wifi[5:]
    uptime = receiver.format_uptime()

    status_probe = ProbedStatusLedController(config)

    try:
        video, encoder, _ = status_probe._video_state()
    except Exception:
        video = None
        encoder = False

    if video is True:
        video_text = "VIDEO OK"
    elif encoder:
        video_text = "VIDEO LOST"
    elif video is False:
        video_text = "VIDEO OFF"
    else:
        video_text = "VIDEO ?"

    if encoder and video is True:
        live_text = "ENC OK"
    elif encoder:
        live_text = "ENC ERR"
    else:
        live_text = "ENC OFF"

    return (
        f"IRL: SYS OK | {read_temperature()} {read_case_temperature()} {read_fan_state()} | "
        f"{audio} | {video_text} | {live_text} | WiFi {wifi} | Up {uptime}"
    )[:220]


def install_expanded_status() -> None:
    original_handle_control = receiver.handle_control

    def handle_control(
        config: dict[str, Any],
        event: dict[str, Any],
        config_dir: Path,
        config_path: Path,
    ) -> str:
        action_text = str(event.get("message", "")).strip()
        action = action_text.split(" ", 1)[0].strip().lower()

        if action == "status":
            message = build_expanded_status(config)
            LOG.info("Remote control: expanded status requested: %s", message)
            return message

        if admin_control.handles(action_text):
            message = admin_control.handle(config, event, config_path)
            LOG.info("Remote control: BELABOX admin action %s: %s", action, message)
            return message

        return original_handle_control(config, event, config_dir, config_path)

    receiver.handle_control = handle_control


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    config_path = Path(sys.argv[1] if len(sys.argv) > 1 else "config.json").resolve()

    try:
        config = receiver.load_config(config_path)
    except Exception:
        logging.getLogger("cometen-irl-alerts").exception("Receiver could not load config")
        return 1

    install_expanded_status()

    leds = ProbedStatusLedController(config)
    leds.start()

    try:
        return receiver.main()
    finally:
        leds.stop()


if __name__ == "__main__":
    raise SystemExit(main())
